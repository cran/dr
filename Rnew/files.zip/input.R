### use setwd for your own directory, not mine.
setwd("C://Documents and Settings//sandy//My Documents//dr3//dr//Rnew")
setwd("z:/R/source/dr3/dr/Rnew")
library(alr3)
data(ais)
ais$one <- rep(1,202)
source("dr.R")
source("psir.R")
source("psaveORIG1.R")
# SIR
summary(s0 <- dr(LBM~log(SSF)+log(Wt)+log(Hg)+log(Ht)+log(WCC)+log(RCC)+
  log(Hc)+log(Ferr),nslices=5,data=ais))
summary(s1 <- update(s0, group=~one,nslices=5))
# SAVE
summary(s2 <- update(s0,method="save",nslices=10))
summary(s3 <- update(s2,method="save",nslices=10,group=~one))

